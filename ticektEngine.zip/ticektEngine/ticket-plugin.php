<?php
/*
Plugin Name: Ticketengine
Description: A simple plugin for a ticket form.
Version: 1.0
Author: Filipengine
*/

// Criar um novo post type
function createCustomPostType() {
    $args = array(
        'public' => true,
        'label'  => 'Support Forms',
        'menu_icon' => 'dashicons-tickets-alt',
        'supports' => array('title', 'editor'), 
    );
    register_post_type('supportform', $args);
}
add_action('init', 'createCustomPostType');


// Adicionar shortcode página edit
function addShortcodeToEditPage($post) {
    if ($post->post_type === 'supportform') {
        echo '<p>Shortcode: [support_form id="' . $post->ID . '"]</p>';
    }
}
add_action('edit_form_after_title', 'addShortcodeToEditPage');


//Função shortcode
function ticketFormShortcode($atts) {
    // Default ID 0 se não tiver
    $atts = shortcode_atts(array('id' => 0,), $atts);
    
    $post_id = $atts['id'];
    
    // Se ID shortcode = ID post
    if ($post_id) {
        $post = get_post($post_id);
        // Se post exite e é tipo "supportform"
        if ($post && $post->post_type === 'supportform') {
            // Conteúdo da form box
            $form_meta_content = get_post_meta($post->ID, 'form_meta_content', true);
            if (!empty($form_meta_content)) {
                $elements = json_decode($form_meta_content);
               
                $form_html = '';
                // Mensagem sucesso (limpar se já estiver)
                if (isset($_GET['email_sent']) && $_GET['email_sent'] === 'true') { // Verifica se ULR contém email_sent
                    // Msg sucesso
                    $successMessage = get_post_meta($post->ID, 'successField', true);
                    $form_html .= '<div class="success-message" style="border: 2px solid green; background-color: #d4edda; 
                    color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 5px; 
                    text-align: center; font-weight: bold;">' . esc_html($successMessage) . '</div>';
                    // Remover email do URL
                    $form_html .= '<script>
                        if (window.history.replaceState) {
                            const url = new URL(window.location);
                            url.searchParams.delete("email_sent");
                            window.history.replaceState(null, null, url);
                        }
                    </script>';
                }
                
                // Mensagem erro genérico
                if (isset($_GET['email_error']) && $_GET['email_error'] === 'true') {
                    $errorMsg = get_post_meta($post->ID, 'failToSendField', true);
                    $form_html .= '<div class="generic-error-message" style="border: 2px solid red; background-color: #f8d7da; 
                    color: #721c24; padding: 10px; text-align: center; font-weight: bold; margin-bottom: 20px;">' . esc_html($errorMsg) . '</div>';
                    $form_html .= '<script>
                        if (window.history.replaceState) {
                            const url = new URL(window.location);
                            url.searchParams.delete("email_error");
                            window.history.replaceState(null, null, url);
                        }
                    </script>';
                }
                
                $form_html .= '<form id="customSupportFormID" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                $form_html .= '<input type="hidden" name="action" value="handle_form_submission">';
                $form_html .= '<input type="hidden" name="post_id" value="' . esc_attr($post->ID) . '">';
                
                //Passa por cada elemento formulário e renderiza de acordo com tipo
                foreach ($elements as $element) {
                    //Nome elemento
                    $elementName = isset($element->name) ? $element->name : sanitize_title($element->text); 
                    switch ($element->type) {
                        case 'text':
                            $form_html .= '<label>' . esc_html($element->label) . '</label>';
                            $form_html .= '<input required style="margin-left:15px" type="text" name="' . esc_attr($elementName) . '"><br>';
                            break;
                        case 'email':
                            $form_html .= '<label>' . esc_html($element->label) . '</label>';
                            $form_html .= '<input required style="margin-left:15px" type="email" name="' . esc_attr($elementName) . '"><br>';
                            break;
                        case 'select':
                            $form_html .= '<label>' . esc_html($element->label) . '</label>';
                            $form_html .= '<select required style="margin-left:15px" name="' . esc_attr($elementName) . '">';
                            foreach ($element->options as $option) {
                                $form_html .= '<option value="' . esc_attr($option) . '">' . esc_html($option) . '</option>';
                            }
                            $form_html .= '</select><br>';
                            break;
                        case 'button':
                            $form_html .= '<button id="submitButtonID" style="margin-top:15px" type="submit">' . esc_html($element->label) . '</button><br>';
                            break;
                    }
                }
                $form_html .= '</form>';
                
                
                // Sripts print elementos
                $form_html .= '<script>
                    var elements = ' . json_encode($elements->labels) . ';
                    console.log(elements);
                </script>';
                
                
                // Return conteúdo formulário descodificado
                return apply_filters('the_content', $form_html);
            }
        }
    }
    return ''; // Return string vazia se post ID = inválido ou tipo incorreto
}
add_shortcode('support_form', 'ticketFormShortcode');


function formSubmission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'])) {
        try {
            // ID de post para identificar contador
            $post_id = intval($_POST['post_id']);
            
            // Recolha contador
            $ticketCounter = intval(get_post_meta($post_id, 'ticketCounter', true));
            if (!$ticketCounter) {
                $ticketCounter = 0; // Default = 0
            }
            $ticketCounter++;
            update_post_meta($post_id, 'ticketCounter', $ticketCounter);
            
            // Email configurado backoffice
            $to = get_post_meta($_POST['post_id'], 'submitEmail', true);

            // Email inserido no formulário
            $formEmail = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';

            // Mensagem a enviar
            $message = '';

            // Conteúdo formulário
            $form_meta_content = get_post_meta($_POST['post_id'], 'form_meta_content', true);
            $elements = json_decode($form_meta_content);
            $message = "Informação de formulário enviada:\n\n";

            // Itera por cada elemento e adiciona à mensagem, se não for botão
            foreach ($elements as $element) {
                if ($element->type !== 'button') {
                    // Se $element tem nome, senão verifica o text
                    $elementName = isset($element->name) ? $element->name : sanitize_title($element->text);
                    $value = isset($_POST[$elementName]) ? $_POST[$elementName] : '';
                    $message .= $element->label . ': ' . $value . "\n";
                }
            }
            
            $subject = 'Ticket de Assistência #' . $ticketCounter;
            
            // Envio email admin
            wp_mail($to, $subject, $message);
            // Cópia de email para user
            wp_mail($formEmail, $subject, $message);

            // Redirecionar com mensagem de sucesso
            wp_redirect(add_query_arg('email_sent', 'true', wp_get_referer()));
            exit;
        } catch (Exception $e) {
            // Redirecionar com mensagem de erro
            wp_redirect(add_query_arg('email_error', 'true', wp_get_referer()));
            exit;
        }
    }
}
add_action('admin_post_handle_form_submission', 'formSubmission'); //Envio com login
add_action('admin_post_nopriv_handle_form_submission', 'formSubmission'); //Envio sem login



// Colunas painel geral 
function generalPanelColumns($columns) {
    // Remover coluna data
    unset($columns['date']);
    
    // Adicionar coluna shortcode
    $columns['shortcode'] = 'Shortcode';
    
    // Adicionar coluna data
    $columns['date'] = 'Date';

    return $columns;
}
add_filter('manage_supportform_posts_columns', 'generalPanelColumns');

// Mostrar conetúdo coluna shortcode
function showShortcodeColumn($column, $post_id) {
    if ($column === 'shortcode') {
        echo '[support_form id="' . $post_id . '"]';
    }
}
add_action('manage_supportform_posts_custom_column', 'showShortcodeColumn', 10, 2);


//------------------------------------------------------Metaboxes------------------------------------------------------//
// Adicionar meta boxes
function addMetaBoxes() {
    add_meta_box(
        'formMetaBox',
        'Formulário',
        'renderFormMetaBox',
        'supportform',
        'normal',
        'high'
    );

    add_meta_box(
        'fieldsMetaBox',
        'Campos',
        'renderFieldsMetaBox',
        'supportform',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'addMetaBoxes');

// Adicionar meta box de configurações adicionais
function addConfigMetaBox() {
    add_meta_box(
        'configMetaBox',
        'Configurações de Envio',
        'renderconfigMetaBox',
        'supportform', 
        'advanced',
        'high'
    );
}
add_action('add_meta_boxes', 'addConfigMetaBox');

// Adicionar meta box de mensagens envio
function addMsgMetaBox() {
    add_meta_box(
        'msgMetaBox',
        'Mensagens de Envio',
        'renderMsgMetaBox',
        'supportform', 
        'advanced',
        'high'
    );
}
add_action('add_meta_boxes', 'addMsgMetaBox');


// Renderiza o conteúdo da meta box do formulário
function renderFormMetaBox($post) {
    /*----------------------------------------RESET SAVED ELEMENTS LIST----------------------------------------*/
    /*
    // Limpar elementos
    $deleted = delete_post_meta_by_key('form_meta_content');

    if ($deleted) {
        echo 'Saved elements list reset successfully.';
    } else {
        echo 'Failed to reset saved elements list.';
    }
    */
    
    
    // Retorna elementos do post, se existem
    $form_meta_content = get_post_meta($post->ID, 'form_meta_content', true);
    if (!empty($form_meta_content)) {
        $elements = json_decode($form_meta_content); // Transforma elementos em string para objetos PHP
    } else {
        $elements = [];
    }

    echo '<div id="form-meta-wrapper" style="display: flex;">'; 
    
    // Coluna 1 - Elementos
    echo '<div class="column" style="width: 40%; padding-right: 20px;">'; 
    echo '<div id="form-meta-box" style="background-color: #ffffff; padding: 20px;">'; 

    // Renderiza todos os elementos presentes
    if (!empty($elements)) {
        foreach ($elements as $element) {
            echo '<div class="rectangle" data-field-type="' . esc_attr($element->type) . '" style="width: 100%; height: 40px; background-color: #ffb800; margin-bottom: 10px; position: relative;">';
            echo '<span class="deleteX" style="color: red; margin-right: 10px; cursor: pointer;">X</span>';
            echo '<span style="color: white; position: absolute; left: 10px; top: 50%; transform: translateY(-50%);">' . esc_html($element->text) . '</span>';
            echo '<span style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">></span>';
            echo '</div>';
        }
    }

    // Campo oculto para guardar informação
    echo '<input type="hidden" name="form_meta_content" id="form-meta-content" value="' . esc_attr($form_meta_content) . '">';
    echo '</div>'; // Fim metaBox
    echo '</div>'; // Fim coluna 1

    // Coluna 2 - Opções
    echo '<div class="column" style="width: 60%; padding-right: 20px;">'; 
    echo '<div id="form-meta-box-2" style="background-color: #ffffff; padding: 20px;">'; 
    // Renderizar uma optionsBox para cada elemento presente na coluna 1
    foreach ($elements as $element) {
        echo '<div class="optionsBox" style="height: 300px; background-color: #ffb800; margin-bottom: 20px; display:none">';
        
        // Renderiza caixa opções de acordo com tipo elemento
        switch ($element->type) {
            case 'text':
                echo '<div style="padding-top:20px; padding-left:20px"><span style="font-size: 20px; color:white"><b>Etiqueta do campo</b></span><br><input class="label" type="text"></div>';
                break;
            case 'email':
                echo '<div style="padding-top:20px; padding-left:20px"><span style="font-size: 20px; color:white"><b>Etiqueta do campo</span></b><br><input class="label" type="text"></div>';
                break;
            case 'select':
                echo '<div style="padding-top:20px; padding-left:20px">';
                echo '<span style="font-size: 20px; color:white"><b>Etiqueta do campo</span></b><br><input class="label" type="text"><br>';
                echo '<div class="selectOptions">';
                echo '<span style="font-size: 20px; color:white"><b>Opção 1</b></span><br><input class="selectOption" type="text"><br>';
                echo '<span style="font-size: 20px; color:white"><b>Opção 2</b></span><br><input class="selectOption" type="text"><br>';
                echo '<span style="font-size: 20px; color:white"><b>Opção 3</b></span><br><input class="selectOption" type="text"><br>';
                echo '<span style="font-size: 20px; color:white"><b>Opção 4</b></span><br><input class="selectOption" type="text"><br>';
                echo '<span style="font-size: 20px; color:white"><b>Opção 5</b></span><br><input class="selectOption" type="text">';
                echo '</div>';
                echo '</div>';
                break;
            case 'button':
                echo '<div style="padding-top:20px; padding-left:20px"><span style="font-size: 20px; color:white"><b>Texto do botão</b></span><br><input class="label" type="text"></div>';
                break;
            default:
                echo '';
        }
        echo '</div>';
    }
    echo '</div>'; // Fim metaBox2
    echo '</div>'; // Fim coluna 2

    echo '</div>'; // Fim wrapper
}


// Renderiza o conteúdo da meta box de configurações adicionais
function renderconfigMetaBox($post) {
    $emailValue = get_post_meta($post->ID, 'submitEmail', true);
    echo '<div style="margin-top: 20px; display: flex; align-items: center;">';
    echo '<label for="emailField" style="margin-right: 10px;">Email:</label>';
    echo '<input type="email" id="emailField" name="emailField" style="flex: 1; padding: 5px;" value="' . esc_attr($emailValue) . '" />';
    echo '</div>';
}

// Renderiza o conteúdo da meta box de configurações adicionais
function renderMsgMetaBox($post) {
    $successFieldValue = get_post_meta($post->ID, 'successField', true);
    $failToSendFieldValue = get_post_meta($post->ID, 'failToSendField', true);

    echo '<div style="margin-top: 20px;">';
    
    // Campo sucesso
    echo '<div style="margin-bottom: 20px;">';
    echo '<label for="successField" style="display: block; margin-bottom: 5px;">Envio com sucesso:</label>';
    echo '<input type="text" id="successField" name="successField" style="width: 100%; padding: 5px;" value="' . esc_attr($successFieldValue) . '"/>';
    echo '</div>';

    // Campo erro envio
    echo '<div style="margin-bottom: 20px;">';
    echo '<label for="failToSendField" style="display: block; margin-bottom: 5px;">Erro ao enviar:</label>';
    echo '<input type="text" id="failToSendField" name="failToSendField" style="width: 100%; padding: 5px;" value="' . esc_attr($failToSendFieldValue) . '"/>';
    echo '</div>';

    echo '</div>';
}

// Guardar campos configurações
function saveConfigMetaBox($post_id) {
    // Verificação permissão
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $email_value = sanitize_email($_POST['emailField']);
    update_post_meta($post_id, 'submitEmail', $email_value);
}
add_action('save_post', 'saveConfigMetaBox');

// Guardar mensagens
function saveMsgMetaBox($post_id) {
    // Verificação permissão
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $sucessFieldValue = sanitize_text_field($_POST['successField']);
    update_post_meta($post_id, 'successField', $sucessFieldValue);
    $failToSendFieldValue = sanitize_text_field($_POST['failToSendField']);
    update_post_meta($post_id, 'failToSendField', $failToSendFieldValue);
}
add_action('save_post', 'saveMsgMetaBox');

// Guardar elementos formulário
function saveFormMetaBoxContent($post_id) {
    // Verificar se o utilizador tem permições de edição
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Verificação e atualização de dados
    if (isset($_POST['form_meta_content'])) {
        update_post_meta($post_id, 'form_meta_content', sanitize_text_field($_POST['form_meta_content']));
    }
}
add_action('save_post', 'saveFormMetaBoxContent');


// Renderiza o conteúdo da meta box dos elementos
function renderFieldsMetaBox($post) {
    echo '<div id="fields-meta-box" style="background-color: #ffffff; padding: 20px;">';
    // Conteúdo da meta box
    echo '<div class="rectangle" data-field-type="text" style="width: 100%; height: 40px; background-color: #ffb800; margin-bottom: 10px; position: relative;">';
    echo '<span style="color: white; position: absolute; left: 10px; top: 50%; transform: translateY(-50%);">Texto</span>';
    echo '<span style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">+</span>';
    echo '</div>';
    echo '<div class="rectangle" data-field-type="email" style="width: 100%; height: 40px; background-color: #ffb800; margin-bottom: 10px; position: relative;">';
    echo '<span style="color: white; position: absolute; left: 10px; top: 50%; transform: translateY(-50%);">Email</span>';
    echo '<span style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">+</span>';
    echo '</div>';
    echo '<div class="rectangle" data-field-type="select" style="width: 100%; height: 40px; background-color: #ffb800; margin-bottom: 10px; position: relative;">';
    echo '<span style="color: white; position: absolute; left: 10px; top: 50%; transform: translateY(-50%);">Seleção</span>';
    echo '<span style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">+</span>';
    echo '</div>';
    echo '<div class="rectangle" data-field-type="button" style="width: 100%; height: 40px; background-color: #ffb800; margin-bottom: 10px; position: relative;">';
    echo '<span style="color: white; position: absolute; left: 10px; top: 50%; transform: translateY(-50%);">Botão</span>';
    echo '<span style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">+</span>';
    echo '</div>';
    echo '</div>';
}



// Scripts
function customMetaBoxesScripts() {
    global $post_type;

    // Executa scripts se tipo de post = 'supportform'
    if ($post_type == 'supportform') {
        ?>
        <style>
            #postdivrich { 
                display: none; /* Ocultar o editor default */
            }
        
            #slugdiv{
                display:none; /* Ocultar campo slug */
            }
            
            .postbox-header .handle-actions{
                display:none;
            }
            
            /* Meta box de formulário e elementos, respetivamente */
            #normal-sortables {
                display: flex;
            }
            
            #formMetaBox {
                order: 1; 
                width: 70%;
            }
            
            #fieldsMetaBox {
                order: 2; 
                width: 30%;
            }
        </style>
        <script>
        jQuery(document).ready(function($) {
            // Atualiza o campo escondido com elementos do formulário
            function updateHiddenInput() {
                var serializedElements = JSON.stringify(elementsArray);
                $('#form-meta-content').val(serializedElements);
            }
            // Conversão de texto para objetos elementos
            function getSavedElements() {
                var serializedElements = $('#form-meta-content').val();
                if (serializedElements) {
                    return JSON.parse(serializedElements);
                }
                return [];
            }
        
            var savedElements = getSavedElements();
            console.log('Saved Elements:', savedElements);
            console.log('Elements Array:', elementsArray);
            
            
            // Preenchimento de campos com dados guardados
            function populateOptionFields() {
                $('.optionsBox').each(function(index) {
                    if (index < savedElements.length) {
                        var element = savedElements[index];
                        
                        var labelInput = $(this).find('.label');
                        labelInput.val(element.label);
                        
                        // Se tiver opções, popular campos
                        if (element.options && element.options.length) {
                            var selectOptions = $(this).find('.selectOption');
                            
                            selectOptions.each(function(optIndex) {
                                if (optIndex < element.options.length) {
                                    $(this).val(element.options[optIndex]);
                                }
                            });
                        }
                    }
                });
            }
            populateOptionFields();
            
            
            // Array de objetos de elementos
            var elementsArray = savedElements;
            

            // Remover elementos
            $('#form-meta-box').on('click', '.deleteX', function() {
                var $rectangle = $(this).closest('.rectangle');
                var index = $('#form-meta-box .rectangle').index($rectangle);  // Index do elemento
                
                //Remove caixa de opções correspondente
                $('#form-meta-box-2 .optionsBox').eq(index).remove();
                
                elementsArray.splice(index, 1);  // Remove elemento correspondente
                updateHiddenInput(); 
                $rectangle.remove(); 
            });
            
            
            // Controlo campos de labels
            $('#form-meta-box-2 .optionsBox .label').on('input', function() {
                var inputValue = $(this).val();  // Valor do input
                var index = $('#form-meta-box-2 .optionsBox .label').index(this);
                elementsArray[index].label = inputValue;  
                updateHiddenInput();
            });
            
            
            //Array para campos select
            var selectOptionValues = [];
            
            // Passa por cada input opções select
            $('#form-meta-box-2 .optionsBox .selectOptions .selectOption').each(function(index) {
                var optionsBoxIndex = $(this).closest('.optionsBox').index();
                // Começar com array vazio
                selectOptionValues[index] = '';
            
                $(this).on('input', function() {
                    // Valor do campo atual
                    var inputValue = $(this).val();  
                    
                    
                    // Atualizar a posição correta do array 
                    selectOptionValues[index] = inputValue;
                    
                    elementsArray[optionsBoxIndex].options = selectOptionValues;
                    updateHiddenInput();
                });
            });
            
            
            // Controlo visibilidade campos opções
            $('#form-meta-box').on('click', '.rectangle', function() {
                var index = $('#form-meta-box .rectangle').index($(this));
                var optionsBox = $('#form-meta-box-2 .optionsBox').eq(index);
                
                // Verificar se o campo já está visivel
                if (optionsBox.is(':visible')) {
                    return; 
                }
                
                // Esconde todos os campos
                $('.optionsBox').hide();
                
                // Mostra campo correspondente
                optionsBox.show();
                
                // Ajuste de tamanho, se > que 320px de altura
                $('.optionsBox').each(function() {
                    var height = $(this)[0].scrollHeight + 20; 
                    if (height < 320) {
                        height = 320; 
                    }
                    $(this).css("height", height + "px");
                });
            });
            
            // Clonagem elementos
            $('#fields-meta-box .rectangle').on('click', function() {
                var $this = $(this);
                var copy = $this.clone(); 
                copy.find('span').each(function() {
                    if ($(this).text() === '+') {
                        $(this).text('>'); // Mudar + para >
                    }
                });
                copy.prepend('<span class="deleteX" style="color: red; margin-right: 10px; cursor: pointer;">X</span>'); //X para apagar
                $('#form-meta-box').append(copy); 
            
                // Criação objetos
                var elementType = $this.data('field-type');
                var elementText = $this.find('span').first().text();
                var elementObject = {
                    type: elementType,
                    text: elementText,
                    label: '',
                    options: ''
                };
                elementsArray.push(elementObject); 
            
                // Update input escondido
                updateHiddenInput();
            
                // Renderização de opção durante clonagem
                var optionsBoxHtml = '';
                switch (elementType) {
                    case 'text':
                        optionsBoxHtml = '<div class="optionsBox" style="height: 300px; background-color: #ffb800; margin-bottom: 20px; display:none">' +
                                            '<div style="padding-top:20px; padding-left:20px">' +
                                                '<span style="font-size: 20px; color:white"><b>Etiqueta do campo</b></span><br>' +
                                                '<input class="label" type="text">' +
                                            '</div>' +
                                        '</div>';
                        break;
                    case 'email':
                        optionsBoxHtml = '<div class="optionsBox" style="height: 300px; background-color: #ffb800; margin-bottom: 20px; display:none">' +
                                            '<div style="padding-top:20px; padding-left:20px">' +
                                                '<span style="font-size: 20px; color:white"><b>Etiqueta do campo</b></span><br>' +
                                                '<input class="label" type="text">' +
                                            '</div>' +
                                        '</div>';
                        break;
                    case 'select':
                        optionsBoxHtml = '<div class="optionsBox" style="height: 300px; background-color: #ffb800; margin-bottom: 20px; display:none">' +
                                            '<div style="padding-top:20px; padding-left:20px">' +
                                                '<span style="font-size: 20px; color:white"><b>Etiqueta do campo</b></span><br>' +
                                                '<input class="label" type="text"><br>' +
                                                '<div class="selectOptions">' +
                                                    '<span style="font-size: 20px; color:white"><b>Opção 1</b></span><br><input class="selectOption" type="text"><br>' +
                                                    '<span style="font-size: 20px; color:white"><b>Opção 2</b></span><br><input class="selectOption" type="text"><br>' +
                                                    '<span style="font-size: 20px; color:white"><b>Opção 3</b></span><br><input class="selectOption" type="text"><br>' +
                                                    '<span style="font-size: 20px; color:white"><b>Opção 4</b></span><br><input class="selectOption" type="text"><br>' +
                                                    '<span style="font-size: 20px; color:white"><b>Opção 5</b></span><br><input class="selectOption" type="text">' +
                                                '</div>' +
                                            '</div>' +
                                        '</div>';
                        break;
                    case 'button':
                        optionsBoxHtml = '<div class="optionsBox" style="height: 300px; background-color: #ffb800; margin-bottom: 20px; display:none">' +
                                            '<div style="padding-top:20px; padding-left:20px">' +
                                                '<span style="font-size: 20px; color:white"><b>Texto do botão</b></span><br>' +
                                                '<input class="label" type="text">' +
                                            '</div>' +
                                        '</div>';
                        break;
                    default:
                        optionsBoxHtml = '';
                }
                $('#form-meta-box-2').append(optionsBoxHtml);
                // Ajuste altura 
                $(".optionsBox").each(function() {
                    var height = $(this)[0].scrollHeight + 20; 
                    $(this).css("height", height + "px");
                });
            });
        });
        </script>
        <?php
        wp_deregister_script('postbox'); // Remover arraste das meta boxes
    }
}
add_action('admin_head', 'customMetaBoxesScripts');


// Substituir string
function textReplace($text) {
    $replace = array(
        'Adicionar novo artigo' => 'Criar novo formulário',
    );

    return strtr($text, $replace);
}
add_filter('gettext', 'textReplace');
add_filter('ngettext', 'substituir_texto');